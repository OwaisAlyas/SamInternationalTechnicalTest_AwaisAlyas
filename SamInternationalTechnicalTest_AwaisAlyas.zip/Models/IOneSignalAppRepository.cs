﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SamInternationalTechnicalTest_AwaisAlyas.Models
{
    public interface IOneSignalAppRepository: IDisposable
    {
        IEnumerable<OneSignalAppsIntegrationViewModel> GetAllApps();
        OneSignalAppsIntegrationViewModel GetAppById(string appId);
        Task CreateApp(string newAppName);
        
        Task UpdateApp(OneSignalAppsIntegrationViewModel app);
    }
}
