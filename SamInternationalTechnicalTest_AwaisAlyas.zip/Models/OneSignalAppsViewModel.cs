﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SamInternationalTechnicalTest_AwaisAlyas.Models
{
    public class OneSignalAppsIntegrationViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string basic_auth_key { get; set; }

    }
}
