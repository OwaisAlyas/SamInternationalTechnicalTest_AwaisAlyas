﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace SamInternationalTechnicalTest_AwaisAlyas.Models
{
    public class OneSignalAppRepository : IOneSignalAppRepository
    {
        string BaseKey= "Basic ODEwZDRmNmUtMmRlMS00MWUzLThmNzAtNTM3NTliY2EwMTAz";//"Basic NWVjZTJhMmItMjBkMy00MjJjLThkNGEtNmM4OGM3Yzk5YzAy"
        public async Task CreateApp(string newAppName)
        {
            using (var httpClient = new HttpClient())
            {
                using (var request = new HttpRequestMessage(new HttpMethod("POST"), "https://onesignal.com/api/v1/apps"))
                {
                    request.Headers.TryAddWithoutValidation("Authorization", BaseKey);

                    request.Content = new StringContent("{\"name\" : \"" + newAppName + "\",\n\"apns_env\": \"production\",\n\"apns_p12\": \"asdsadcvawe223cwef...\",\n\"apns_p12_password\": \"FooBar\",\n\"organization_id\": \"your_organization_id\",\n\"gcm_key\": \"a gcm push key\"}");
                    request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json");

                    var response = await httpClient.SendAsync(request);
                }
            }
        }

       
        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<OneSignalAppsIntegrationViewModel> GetAllApps()
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://onesignal.com/api/v1/apps");
            request.Method = "GET";
            // Account Auth Key
            request.Headers.Add("Authorization", BaseKey);

            var response = request.GetResponse();
            string applist;
            using (var sr = new StreamReader(response.GetResponseStream()))
            {
                applist = sr.ReadToEnd();
                List<OneSignalAppsIntegrationViewModel> jsonlist = JsonConvert.DeserializeObject<List<OneSignalAppsIntegrationViewModel>>(applist);
                return jsonlist;
            }
        }

        public OneSignalAppsIntegrationViewModel GetAppById(string appId)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://onesignal.com/api/v1/apps/"+appId);
            request.Method = "GET";
            request.Headers.Add("Authorization", BaseKey);

            var response = request.GetResponse();
            string applist;
            using (var sr = new StreamReader(response.GetResponseStream()))
            {
                applist = sr.ReadToEnd();
                OneSignalAppsIntegrationViewModel app = JsonConvert.DeserializeObject<OneSignalAppsIntegrationViewModel>(applist);
                return app;
            }
        }

        public async Task UpdateApp(OneSignalAppsIntegrationViewModel app)
        {
            using (var httpClient = new HttpClient())
            {
                using (var request = new HttpRequestMessage(new HttpMethod("PUT"), "https://onesignal.com/api/v1/apps/"+app.Id))
                {
                    request.Headers.TryAddWithoutValidation("Authorization", BaseKey);

                    request.Content = new StringContent("{\"name\" : \"" + app.Name + "\"}");
                    request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json");

                    var response = await httpClient.SendAsync(request);
                }
            }
        }
    }
}
